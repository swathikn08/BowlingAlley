package com.bowlingalley.BowlingAlley.ControllerTests;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.bowlingalley.Model.Player;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@AutoConfigureMockMvc
@SpringBootTest
public class PlayerControllerTests {

	@Autowired
	private MockMvc mockMVC ;

	@Autowired
	WebApplicationContext webApplicationContext;

	ObjectMapper objMap = new ObjectMapper();

	@Test
	@DisplayName(value="Test Add Player")
	public void addPlayerTest() throws Exception{
		List<Player> player = new  ArrayList<>(Arrays.asList(
				new Player("John"),
				new Player("Jack")
				));
		System.out.println("++ player is ++"+player);

		String jsonRequest = objMap.writeValueAsString(player);
		System.out.println("++ jsonRequest is ++"+jsonRequest);

		System.out.println("++ mockMVC is ++"+mockMVC);
		MvcResult result = mockMVC.perform(
				MockMvcRequestBuilders.post("/players/addPlayer")
				.contentType(MediaType.APPLICATION_JSON_VALUE).content(jsonRequest))
				.andExpect(status().isOk()).andReturn();

		int status = result.getResponse().getStatus();
		Assert.assertEquals(200,status);
	}

	@Test
	@DisplayName(value="Test Get All Players")
	public void getAllPlayerTests() throws Exception {
		String uri = "/players";
		MvcResult mvcResult = mockMVC.perform(MockMvcRequestBuilders.get(uri)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk()).andReturn();

		int status = mvcResult.getResponse().getStatus();
		Assert.assertEquals(200, status);

	}

	@Test
	@DisplayName(value="Test Individual Player Details")
	public void getPlayerList() throws Exception {
		String uri = "/players/player-details/1";
		MvcResult mvcResult = mockMVC.perform(MockMvcRequestBuilders.get(uri)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk()).andReturn();

		
		int status = mvcResult.getResponse().getStatus();
		Assert.assertEquals(200, status);

	}
	
	@Test
	@DisplayName(value="Test Player Score Board Details")

	public void getPlayerScoreBoard() throws Exception {
		String uri = "/players/1/scoreBoard";
		MvcResult mvcResult = mockMVC.perform(MockMvcRequestBuilders.get(uri)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk()).andReturn();

		
		int status = mvcResult.getResponse().getStatus();
		Assert.assertEquals(200, status);

	}
}

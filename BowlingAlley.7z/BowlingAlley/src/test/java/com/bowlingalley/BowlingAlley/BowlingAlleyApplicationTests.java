package com.bowlingalley.BowlingAlley;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BowlingAlleyApplicationTests {
	
}

package com.bowlingalley.BowlingAlley.ControllerTests;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.bowlingalley.Model.Player;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@AutoConfigureMockMvc
@SpringBootTest
public class GameControllerTest {

	@Autowired
	private MockMvc mockMVC ;

	@Autowired
	WebApplicationContext webApplicationContext;

	ObjectMapper objMap = new ObjectMapper();

	@Test
	@DisplayName(value="Testing Assign Lanes")
	public void getAllPlayerTests() throws Exception {
		String uri = "/players/assignLane";
		MvcResult mvcResult = mockMVC.perform(MockMvcRequestBuilders.get(uri)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk()).andReturn();

		int status = mvcResult.getResponse().getStatus();
		Assert.assertEquals(200, status);

	}

	@Test
	@DisplayName(value="Test Start Game")
	public void getPlayerList() throws Exception {
		String uri = "/startGame/1";
		MvcResult mvcResult = mockMVC.perform(MockMvcRequestBuilders.get(uri)
				.accept(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk()).andReturn();

		
		int status = mvcResult.getResponse().getStatus();
		Assert.assertEquals(200, status);

	}
	
}

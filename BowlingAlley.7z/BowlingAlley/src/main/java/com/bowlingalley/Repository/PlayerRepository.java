package com.bowlingalley.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.bowlingalley.Model.Player;

public interface PlayerRepository extends CrudRepository<Player, Integer> {
	void save(List<Player> player);
	
}

package com.bowlingalley.Repository;


import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bowlingalley.Model.Game;


public interface GameRepository extends CrudRepository<Game, Integer>{

	void save(Optional<Game> game);

}
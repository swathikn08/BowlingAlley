package com.bowlingalley.Model;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Player")
public class Player {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private int game_id;
	private int laneId;
	private int currentScore;
	private int totalScore;
	private int totalStrikes;
	private int totalSpares;

	public Player() {
		super();
	}
	public Player(int id) {
		this.id= id;
	}
	public Player(String name) {
		this.name= name;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getGame_id() {
		return game_id;
	}
	public void setGame_id(int game_id) {
		this.game_id = game_id;
	}

	public int getLaneId() {
		return laneId;
	}

	public void setLaneId(int laneId) {
		this.laneId = laneId;
	}

	public int getCurrentScore() {
		return currentScore;
	}
	public void setCurrentScore(int currentScore) {
		this.currentScore += currentScore;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore += totalScore;
	}

	public int getTotalStrikes() {
		return totalStrikes;
	}
	public void setTotalStrikes(int totalStrikes) {
		this.totalStrikes = totalStrikes;
	}
	public int getTotalSpares() {
		return totalSpares;
	}
	public void setTotalSpares(int totalSpares) {
		this.totalSpares = totalSpares;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name +  ", game_id=" + game_id
				+ ", laneId=" + laneId + ", currentScore=" + currentScore + ", totalScore=" + totalScore
				+ ", totalStrikes=" + totalStrikes + ", totalSpares="
				+ totalSpares + "]";
	}



}

package com.bowlingalley.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bowlingalley.Model.Game;
import com.bowlingalley.Model.Player;
import com.bowlingalley.Repository.GameRepository;
import com.bowlingalley.Repository.PlayerRepository;
import com.bowlingalley.Response.LaneResponse;

@Service
public class GameService  {

	@Autowired
	GameRepository gameRepository;
	@Autowired
	PlayerRepository playerRepository;


	public LaneResponse assignLane() {
		LaneResponse response = new LaneResponse();
		List<Game> lanes = new ArrayList<>();
		gameRepository.findAll().forEach(lanes::add);
		List<Player> players = new ArrayList<>();
		playerRepository.findAll().forEach(players::add);
		
		int player_num =0;

		for(int no_of_lanes=0;no_of_lanes<lanes.size();no_of_lanes++) {
			Game lane = lanes.get(no_of_lanes);
			for(int player_lane=0; lane.getPlayers().size()<3 && player_num<players.size();player_lane++) {
				Player player = players.get(player_num);
				lane.getPlayers().add(player_lane, player);
				player_num++;
				gameRepository.save(lane);
				player.setLaneId(lane.getId());
				playerRepository.save(player);
			}
		}
		response.setLanes(lanes);
		return response;
	}		

	public LaneResponse getLanes() {
		LaneResponse response = new LaneResponse();
		List<Game> lanes = new ArrayList<>();
		gameRepository.findAll().forEach(lanes::add);
		response.setLanes(lanes);
		return response;
	}


	public void startGame(Integer id)  {

		List<Player> players = new ArrayList<>();
		playerRepository.findAll()
		.forEach(players::add);

		for(int player_count =0 ;player_count< players.size();player_count++) {
			
			HashMap<Integer, List<Integer>> score_board = new HashMap<>();

			int setCounter = 1;
			int MAX_SETS = 10;
			int MAX_ATTEMPTS_PER_SET = 2;
			int num_strikes = 0;
			int num_spares = 0;
			Player player = players.get(player_count);

			while(setCounter<=MAX_SETS) {
				int STANDING_PINS = 10;
	
				for(int attempt_set = 1; attempt_set<=MAX_ATTEMPTS_PER_SET;attempt_set++ ) {
					
					int NUM_PINS_DOWN = takeShot(STANDING_PINS);
					STANDING_PINS = STANDING_PINS - NUM_PINS_DOWN;
					
					if(NUM_PINS_DOWN == 10  && attempt_set == 1)
					{
						STANDING_PINS=10;
						num_strikes++;
						player.setTotalStrikes(num_strikes);
						player.setCurrentScore(20);
						break;

					}else if (STANDING_PINS == 0 &&attempt_set == 2 ) {

						num_spares++;
						player.setTotalSpares(num_spares);
						player.setCurrentScore(NUM_PINS_DOWN+5);					

					}else {
						player.setCurrentScore(NUM_PINS_DOWN);
					}
					
					if (setCounter<MAX_SETS) {
						if((NUM_PINS_DOWN == 10  && attempt_set == 1) || 
								(STANDING_PINS == 0 &&attempt_set == 2 )) {
							MAX_ATTEMPTS_PER_SET++;							
						}
					}
					
					playerRepository.save(player);
				}
				setCounter++;
			}
			player.setTotalScore(player.getCurrentScore());
			playerRepository.save(player);
		}	
	}


	private int takeShot(int STANDING_PINS) {
		return 0 + (int)(Math.random() * ((STANDING_PINS - 0) + 1));
	}


};

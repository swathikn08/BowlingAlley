package com.bowlingalley.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bowlingalley.Repository.GameRepository;
import com.bowlingalley.Repository.PlayerRepository;
import com.bowlingalley.Response.AddPlayerResponse;
import com.bowlingalley.Response.AllPlayersResponse;
import com.bowlingalley.Response.PlayerDetailsResponse;
import com.bowlingalley.Response.ScoreBoardResponse;
import com.bowlingalley.Model.Game;
import com.bowlingalley.Model.Player;

@Service
public class PlayerService {

	@Autowired
	PlayerRepository playerRepository;
	GameRepository laneRepository;
	
	public AllPlayersResponse getAllPlayers() {
		AllPlayersResponse response = new AllPlayersResponse();
		List<Player> players = new ArrayList<>();
		playerRepository.findAll()
		.forEach(players::add);
		response.setPlayers(players);
		return response;
	}

	public AddPlayerResponse addPlayer(List<Player> player) {
		AddPlayerResponse response = new AddPlayerResponse();
		int game_id = generteGameId();
		for (Player p : player) {
			p.setGame_id(game_id);
			playerRepository.save(p); 
		}
		response.setGame_id(game_id);
		return response;
	}

	private int generteGameId() {
		Random game_id = new Random();
		return game_id.nextInt(1000);
	}
	

	public void updatePlayer(Integer id, Player player){
		playerRepository.save(player);
	}
	public void deletePlayer(Integer id) {
		playerRepository.deleteById(id);
	}

	public PlayerDetailsResponse playerDetailsResponse(Integer playerId) {

		System.out.println("++ getPlayerDetails  +++");

		PlayerDetailsResponse response = new PlayerDetailsResponse();
		HashMap<String, Object> playerDetails = new HashMap<String, Object>();

		playerRepository.findAll() .forEach(p->{ if(p.getId()==playerId) {
			playerDetails.put("Name : ", p.getName()); 
			playerDetails.put("Game ID :",p.getGame_id());
			playerDetails.put("Lane ID : ", p.getLaneId()); 
		} });

		response.setPlayerDetails(playerDetails);
		return  response;
	}

	public ScoreBoardResponse getPlayerScoreBoard(int playerId) {
		
		ScoreBoardResponse response = new ScoreBoardResponse();
		HashMap<String, Object> playerScoreBoard = new HashMap<String, Object>();

		playerRepository.findAll()
		.forEach(p->{
			if(p.getId()==playerId) {
				playerScoreBoard.put("Name : ", p.getName());
				playerScoreBoard.put("Lane ID :",p.getLaneId());
				playerScoreBoard.put("Current Score :", p.getCurrentScore());
				playerScoreBoard.put("Total Score :", p.getTotalScore());
				playerScoreBoard.put("Total Spare :", p.getTotalSpares());
				playerScoreBoard.put("Total Strikes :", p.getTotalStrikes());
			}
		});

		response.setPlayerScoreBoard(playerScoreBoard);

		return response;
	}

}


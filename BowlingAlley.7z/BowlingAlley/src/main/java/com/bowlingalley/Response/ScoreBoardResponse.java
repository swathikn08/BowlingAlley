package com.bowlingalley.Response;

import java.util.HashMap;

public class ScoreBoardResponse {

	public HashMap<String, Object> getPlayerScoreBoard() {
		return playerScoreBoard;
	}

	public void setPlayerScoreBoard(HashMap<String, Object> playerScoreBoard) {
		this.playerScoreBoard = playerScoreBoard;
	}

	HashMap<String, Object> playerScoreBoard = new HashMap<String, Object>();
}

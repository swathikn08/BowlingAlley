package com.bowlingalley.Response;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.bowlingalley.Model.Game;

public class LaneResponse {
	
	 
	List<Game> lanes = new ArrayList<>();
	public List<Game> getLanes() {
		return lanes;
	}

	public void setLanes(List<Game> lanes) {
		this.lanes = lanes;
	}

	
}

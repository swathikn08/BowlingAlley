package com.bowlingalley.Response;

import java.util.HashMap;

public class PlayerDetailsResponse {
		
	HashMap<String,Object> playerDetails;

	public HashMap<String, Object> getPlayerDetails() {
		return playerDetails;
	}

	public void setPlayerDetails(HashMap<String, Object> playerDetails) {
		this.playerDetails = playerDetails;
	}
}

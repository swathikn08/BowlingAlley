package com.bowlingalley.Response;

import java.util.ArrayList;
import java.util.List;

import com.bowlingalley.Model.Player;

public class AllPlayersResponse {

	List<Player> players = new ArrayList<>();

	public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}
}

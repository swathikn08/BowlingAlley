package com.bowlingalley.Response;

public class AddPlayerResponse {
	private int game_id;

	public int getGame_id() {
		return game_id;
	}

	public void setGame_id(int game_id) {
		this.game_id = game_id;
	}

}

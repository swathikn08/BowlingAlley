package com.bowlingalley.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bowlingalley.Model.Player;
import com.bowlingalley.Response.AddPlayerResponse;
import com.bowlingalley.Response.AllPlayersResponse;
import com.bowlingalley.Response.PlayerDetailsResponse;
import com.bowlingalley.Response.ScoreBoardResponse;
import com.bowlingalley.Service.PlayerService;

import org.springframework.http.MediaType;


@RestController
public class PlayerController {

	@Autowired
	PlayerService playerservice;


	@RequestMapping(value= "/players", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AllPlayersResponse> getAllPlayers() {
		return ResponseEntity.ok(playerservice.getAllPlayers());
	}
	
	@RequestMapping(value= "/players/player-details/{playerId}",produces = MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<PlayerDetailsResponse> playerDetailsResponse(@PathVariable int playerId) {
		return ResponseEntity.ok(playerservice.playerDetailsResponse(playerId));
	}

	
	@RequestMapping(value= "/players/{playerId}/scoreBoard",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ScoreBoardResponse>  getPlayerScoreBoard(@PathVariable int playerId) {
		return ResponseEntity.ok(playerservice.getPlayerScoreBoard(playerId));
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "players/addPlayer",consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AddPlayerResponse> addPlayer(@RequestBody List<Player> player) {
		return ResponseEntity.ok( playerservice.addPlayer(player));
		
	}

	@RequestMapping(method =RequestMethod.PUT,value="/players/update-player/{id}",consumes = MediaType.APPLICATION_JSON_VALUE)
	void updatePlayer(@PathVariable Integer id,@RequestBody Player player) {
		playerservice.updatePlayer(id,player); 
	}

	@RequestMapping(method =RequestMethod.DELETE,value="/players/delete-player/{id}",consumes = MediaType.APPLICATION_JSON_VALUE) 
	void deletePlayer(@PathVariable Integer id) { 
		playerservice.deletePlayer(id);
	}

}

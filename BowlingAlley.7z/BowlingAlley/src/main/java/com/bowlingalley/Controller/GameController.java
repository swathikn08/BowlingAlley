package com.bowlingalley.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bowlingalley.Model.Game;
import com.bowlingalley.Response.AllPlayersResponse;
import com.bowlingalley.Response.LaneResponse;
import com.bowlingalley.Service.GameService;

@RestController
public class GameController {

	@Autowired
	GameService gameService;
		
	
	@RequestMapping(value= "/players/assignLane", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LaneResponse> assignLane() {
		return ResponseEntity.ok(gameService.assignLane());
	}
	
	
	@RequestMapping(value= "/players/lanes", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LaneResponse> getLanes() {
		return ResponseEntity.ok(gameService.getLanes());

	}
	
	
	@RequestMapping(value= "/startGame/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void startGame(@PathVariable Integer id) {
		 gameService.startGame(id);
	}
	
	

}

package com.bowlingalley;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bowlingalley.Model.Game;
import com.bowlingalley.Repository.GameRepository;

@SpringBootApplication
public class BowlingAlleyApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(BowlingAlleyApplication.class, args);
	
	}
	@Autowired
	private GameRepository laneRepositiry;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Game lane1 = new Game (1);
		Game lane2 = new Game(2);
		Game lane3 = new Game(3);
		
		laneRepositiry.save(lane1);
		laneRepositiry.save(lane2);
		laneRepositiry.save(lane3);
	}

	
}
